﻿// Decompiled with JetBrains decompiler
// Type: Stand.Program
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 980AC0A4-9213-45D7-A2A8-808DB864A7B9
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.2_[unknowncheats.me]_\Stand for FH5.exe

using System;
using System.Windows.Forms;

namespace Stand
{
  internal static class Program
  {
    [STAThread]
    private static void Main()
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run((Form) new Form1());
    }
  }
}
