﻿// Decompiled with JetBrains decompiler
// Type: Stand.State
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 980AC0A4-9213-45D7-A2A8-808DB864A7B9
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.2_[unknowncheats.me]_\Stand for FH5.exe

using System;
using System.Windows.Forms;

namespace Stand
{
  internal class State
  {
    public static bool game_focused = false;
    public static IntPtr cursor_og = IntPtr.Zero;
    public static Cursor cursor_replacement = (Cursor) null;
  }
}
