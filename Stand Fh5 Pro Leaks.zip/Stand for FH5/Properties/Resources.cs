﻿// Decompiled with JetBrains decompiler
// Type: Stand.Properties.Resources
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 980AC0A4-9213-45D7-A2A8-808DB864A7B9
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.2_[unknowncheats.me]_\Stand for FH5.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Stand.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Stand.Properties.Resources.resourceMan == null)
          Stand.Properties.Resources.resourceMan = new ResourceManager("Stand.Properties.Resources", typeof (Stand.Properties.Resources).Assembly);
        return Stand.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => Stand.Properties.Resources.resourceCulture;
      set => Stand.Properties.Resources.resourceCulture = value;
    }

    internal static byte[] Blank => (byte[]) Stand.Properties.Resources.ResourceManager.GetObject(nameof (Blank), Stand.Properties.Resources.resourceCulture);
  }
}
