﻿// Decompiled with JetBrains decompiler
// Type: Stand.Properties.Settings
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 980AC0A4-9213-45D7-A2A8-808DB864A7B9
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.2_[unknowncheats.me]_\Stand for FH5.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace Stand.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default => Settings.defaultInstance;
  }
}
