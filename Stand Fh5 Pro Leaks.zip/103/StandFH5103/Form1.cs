﻿// Decompiled with JetBrains decompiler
// Type: Stand.Form1
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B37E4492-CA6E-4E66-880F-1A3CC762E837
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.3\Stand for FH5.exe

using Stand.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Stand
{
  public class Form1 : Form
  {
    private IContainer components;
    private StatusStrip statusStrip1;
    private ToolStripStatusLabel toolStripStatusLabel1;
    private CheckBox lockcrToggle;
    private NumericUpDown lockcrVal;
    private FlowLayoutPanel flowLayoutPanel1;
    private GroupBox groupBox1;
    private Timer processWaitTimer;
    private GroupBox groupBox2;
    private Timer patternscanTimer;
    private Button getSpinSuperBtn;
    private Timer mainloopTimer;
    private Button getSpinRegularBtn;
    private NumericUpDown getSpinRegularVal;
    private NumericUpDown getSpinSuperVal;
    private GroupBox groupBox3;
    private CheckBox cursorToggle;
    private Label autoshowAvailableLabel;
    private ComboBox autoshowAvailableBox;
    private Timer processStartTimer;
    private Button autoshowAllfree;

    public Form1() => this.InitializeComponent();

    private void Form1_Load(object sender, EventArgs e) => this.processInit();

    private void Form1_FormClosing(object sender, FormClosingEventArgs e) => Backend.die();

    private void processInit()
    {
      if (Backend.checkProcess())
      {
        this.processFound();
      }
      else
      {
        this.toolStripStatusLabel1.Text = "Please open Forza Horizon 5.";
        this.processWaitTimer.Start();
      }
    }

    private void Form1_Resize(object sender, EventArgs e)
    {
      Size size = this.flowLayoutPanel1.Size;
      size.Width = this.Size.Width - 40;
      size.Height = this.Size.Height - 76;
      this.flowLayoutPanel1.Size = size;
    }

    private void processWaitTimer_Tick(object sender, EventArgs e)
    {
      if (!Backend.checkProcess())
        return;
      this.processWaitTimer.Stop();
      this.processStartTimer.Start();
    }

    private void processStartTimer_Tick(object sender, EventArgs e)
    {
      this.processStartTimer.Stop();
      this.processFound();
    }

    private void processFound()
    {
      this.toolStripStatusLabel1.Text = "Scanning patterns...";
      Backend.patternscanInit();
      this.patternscanTimer.Start();
    }

    private void patternscanTimer_Tick(object sender, EventArgs e)
    {
      int num = Backend.patternscanStatus();
      if (num == 0)
        return;
      this.patternscanTimer.Stop();
      if (num == 1)
        this.toolStripStatusLabel1.Text = "Ready.";
      else
        this.toolStripStatusLabel1.Text = "Failed to find all patterns. (Code: " + num.ToString() + ")";
      this.mainloopTimer.Start();
    }

    private void mainloopTimer_Tick(object sender, EventArgs e)
    {
      StringBuilder a1 = new StringBuilder(20);
      Backend.mainloop(a1, (long) a1.Capacity);
      string str1 = a1.ToString();
      if (str1.Length != 0)
      {
        if (!(str1 == "reset"))
        {
          if (!(str1 == "focus"))
          {
            if (str1 == "unfocus")
              State.game_focused = false;
          }
          else
            State.game_focused = true;
        }
        else
        {
          this.mainloopTimer.Stop();
          this.processInit();
        }
      }
      if (this.cursorToggle.Checked && State.game_focused)
      {
        if (!(State.cursor_og == IntPtr.Zero))
          return;
        State.cursor_og = this.Cursor.CopyHandle();
        if (State.cursor_replacement == (Cursor) null)
        {
          string str2 = Path.GetTempPath() + Guid.NewGuid().ToString() + ".cur";
          using (FileStream fileStream = File.Open(str2, FileMode.Create))
          {
            using (MemoryStream memoryStream = new MemoryStream(Resources.Blank))
              memoryStream.WriteTo((Stream) fileStream);
            fileStream.Flush();
            fileStream.Close();
          }
          State.cursor_replacement = new Cursor(Stand.Windows.LoadCursorFromFile(str2));
        }
        Stand.Windows.SetSystemCursor(State.cursor_replacement.CopyHandle(), OCR_SYSTEM_CURSORS.OCR_NORMAL);
      }
      else
      {
        if (!(State.cursor_og != IntPtr.Zero))
          return;
        Stand.Windows.SetSystemCursor(State.cursor_og, OCR_SYSTEM_CURSORS.OCR_NORMAL);
        Stand.Windows.DestroyIcon(State.cursor_og);
        State.cursor_og = IntPtr.Zero;
      }
    }

    private void getSpinRegularBtn_Click(object sender, EventArgs e) => Backend.getSpinRegular((int) this.getSpinRegularVal.Value);

    private void getSpinSuperBtn_Click(object sender, EventArgs e) => Backend.getSpinSuper((int) this.getSpinSuperVal.Value);

    private void lockcrToggle_CheckedChanged(object sender, EventArgs e)
    {
      if (this.lockcrToggle.Checked)
        Backend.lockcrSet((int) this.lockcrVal.Value);
      else
        Backend.lockcrUnset();
    }

    private void lockcrVal_ValueChanged(object sender, EventArgs e)
    {
      if (!this.lockcrToggle.Checked)
        return;
      Backend.lockcrSet((int) this.lockcrVal.Value);
    }

    private void autoshowAvailableBox_SelectedIndexChanged(object sender, EventArgs e) => Backend.autoshowAvailableSet(this.autoshowAvailableBox.SelectedIndex);

    private void autoshowAllfree_Click(object sender, EventArgs e) => Backend.autoshowAllfree();

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Form1));
      this.statusStrip1 = new StatusStrip();
      this.toolStripStatusLabel1 = new ToolStripStatusLabel();
      this.lockcrToggle = new CheckBox();
      this.lockcrVal = new NumericUpDown();
      this.flowLayoutPanel1 = new FlowLayoutPanel();
      this.groupBox1 = new GroupBox();
      this.getSpinSuperVal = new NumericUpDown();
      this.getSpinRegularVal = new NumericUpDown();
      this.getSpinRegularBtn = new Button();
      this.getSpinSuperBtn = new Button();
      this.groupBox2 = new GroupBox();
      this.autoshowAllfree = new Button();
      this.autoshowAvailableLabel = new Label();
      this.autoshowAvailableBox = new ComboBox();
      this.groupBox3 = new GroupBox();
      this.cursorToggle = new CheckBox();
      this.processWaitTimer = new Timer(this.components);
      this.patternscanTimer = new Timer(this.components);
      this.mainloopTimer = new Timer(this.components);
      this.processStartTimer = new Timer(this.components);
      this.statusStrip1.SuspendLayout();
      this.lockcrVal.BeginInit();
      this.flowLayoutPanel1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.getSpinSuperVal.BeginInit();
      this.getSpinRegularVal.BeginInit();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      this.statusStrip1.Items.AddRange(new ToolStripItem[1]
      {
        (ToolStripItem) this.toolStripStatusLabel1
      });
      this.statusStrip1.Location = new Point(0, 155);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new Size(686, 22);
      this.statusStrip1.SizingGrip = false;
      this.statusStrip1.TabIndex = 1;
      this.statusStrip1.Text = "statusStrip1";
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new Size(74, 17);
      this.toolStripStatusLabel1.Text = "Please wait...";
      this.lockcrToggle.AutoSize = true;
      this.lockcrToggle.Location = new Point(6, 24);
      this.lockcrToggle.Name = "lockcrToggle";
      this.lockcrToggle.Size = new Size(85, 17);
      this.lockcrToggle.TabIndex = 3;
      this.lockcrToggle.Text = "Lock Credits";
      this.lockcrToggle.UseVisualStyleBackColor = true;
      this.lockcrToggle.CheckedChanged += new EventHandler(this.lockcrToggle_CheckedChanged);
      this.lockcrVal.Location = new Point(97, 21);
      this.lockcrVal.Maximum = new Decimal(new int[4]
      {
        999999999,
        0,
        0,
        0
      });
      this.lockcrVal.Name = "lockcrVal";
      this.lockcrVal.Size = new Size(164, 20);
      this.lockcrVal.TabIndex = 4;
      this.lockcrVal.Value = new Decimal(new int[4]
      {
        10000000,
        0,
        0,
        0
      });
      this.lockcrVal.ValueChanged += new EventHandler(this.lockcrVal_ValueChanged);
      this.flowLayoutPanel1.Controls.Add((Control) this.groupBox1);
      this.flowLayoutPanel1.Controls.Add((Control) this.groupBox2);
      this.flowLayoutPanel1.Controls.Add((Control) this.groupBox3);
      this.flowLayoutPanel1.Location = new Point(12, 12);
      this.flowLayoutPanel1.Name = "flowLayoutPanel1";
      this.flowLayoutPanel1.Size = new Size(662, 136);
      this.flowLayoutPanel1.TabIndex = 4;
      this.groupBox1.Controls.Add((Control) this.getSpinSuperVal);
      this.groupBox1.Controls.Add((Control) this.getSpinRegularVal);
      this.groupBox1.Controls.Add((Control) this.getSpinRegularBtn);
      this.groupBox1.Controls.Add((Control) this.getSpinSuperBtn);
      this.groupBox1.Controls.Add((Control) this.lockcrVal);
      this.groupBox1.Controls.Add((Control) this.lockcrToggle);
      this.groupBox1.Location = new Point(3, 3);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(269, 121);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Self";
      this.getSpinSuperVal.Location = new Point(6, 89);
      this.getSpinSuperVal.Maximum = new Decimal(new int[4]
      {
        999999999,
        0,
        0,
        0
      });
      this.getSpinSuperVal.Minimum = new Decimal(new int[4]
      {
        999999999,
        0,
        0,
        int.MinValue
      });
      this.getSpinSuperVal.Name = "getSpinSuperVal";
      this.getSpinSuperVal.Size = new Size(120, 20);
      this.getSpinSuperVal.TabIndex = 7;
      this.getSpinSuperVal.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.getSpinRegularVal.Location = new Point(6, 61);
      this.getSpinRegularVal.Maximum = new Decimal(new int[4]
      {
        999999999,
        0,
        0,
        0
      });
      this.getSpinRegularVal.Minimum = new Decimal(new int[4]
      {
        999999999,
        0,
        0,
        int.MinValue
      });
      this.getSpinRegularVal.Name = "getSpinRegularVal";
      this.getSpinRegularVal.Size = new Size(120, 20);
      this.getSpinRegularVal.TabIndex = 5;
      this.getSpinRegularVal.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.getSpinRegularBtn.Location = new Point(131, 58);
      this.getSpinRegularBtn.Name = "getSpinRegularBtn";
      this.getSpinRegularBtn.Size = new Size(130, 23);
      this.getSpinRegularBtn.TabIndex = 6;
      this.getSpinRegularBtn.Text = "Add Wheelspins";
      this.getSpinRegularBtn.UseVisualStyleBackColor = true;
      this.getSpinRegularBtn.Click += new EventHandler(this.getSpinRegularBtn_Click);
      this.getSpinSuperBtn.Location = new Point(131, 86);
      this.getSpinSuperBtn.Name = "getSpinSuperBtn";
      this.getSpinSuperBtn.Size = new Size(130, 23);
      this.getSpinSuperBtn.TabIndex = 8;
      this.getSpinSuperBtn.Text = "Add Super Wheelspins";
      this.getSpinSuperBtn.UseVisualStyleBackColor = true;
      this.getSpinSuperBtn.Click += new EventHandler(this.getSpinSuperBtn_Click);
      this.groupBox2.Controls.Add((Control) this.autoshowAllfree);
      this.groupBox2.Controls.Add((Control) this.autoshowAvailableLabel);
      this.groupBox2.Controls.Add((Control) this.autoshowAvailableBox);
      this.groupBox2.Location = new Point(278, 3);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(200, 81);
      this.groupBox2.TabIndex = 9;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Autoshow";
      this.autoshowAllfree.Location = new Point(10, 42);
      this.autoshowAllfree.Name = "autoshowAllfree";
      this.autoshowAllfree.Size = new Size(178, 23);
      this.autoshowAllfree.TabIndex = 7;
      this.autoshowAllfree.Text = "Make All Cars Free";
      this.autoshowAllfree.UseVisualStyleBackColor = true;
      this.autoshowAllfree.Click += new EventHandler(this.autoshowAllfree_Click);
      this.autoshowAvailableLabel.AutoSize = true;
      this.autoshowAvailableLabel.Location = new Point(7, 19);
      this.autoshowAvailableLabel.Name = "autoshowAvailableLabel";
      this.autoshowAvailableLabel.Size = new Size(54, 13);
      this.autoshowAvailableLabel.TabIndex = 1;
      this.autoshowAvailableLabel.Text = "Rare Cars";
      this.autoshowAvailableBox.FormattingEnabled = true;
      this.autoshowAvailableBox.Items.AddRange(new object[3]
      {
        (object) "Hidden (Default)",
        (object) "Shown",
        (object) "Shown Exclusively"
      });
      this.autoshowAvailableBox.Location = new Point(67, 15);
      this.autoshowAvailableBox.Name = "autoshowAvailableBox";
      this.autoshowAvailableBox.Size = new Size(121, 21);
      this.autoshowAvailableBox.TabIndex = 0;
      this.autoshowAvailableBox.Text = "Hidden (Default)";
      this.autoshowAvailableBox.SelectedIndexChanged += new EventHandler(this.autoshowAvailableBox_SelectedIndexChanged);
      this.groupBox3.Controls.Add((Control) this.cursorToggle);
      this.groupBox3.Location = new Point(484, 3);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(172, 49);
      this.groupBox3.TabIndex = 10;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Game";
      this.cursorToggle.AutoSize = true;
      this.cursorToggle.Location = new Point(6, 19);
      this.cursorToggle.Name = "cursorToggle";
      this.cursorToggle.Size = new Size(157, 17);
      this.cursorToggle.TabIndex = 0;
      this.cursorToggle.Text = "Hide Cursor When Focused";
      this.cursorToggle.UseVisualStyleBackColor = true;
      this.processWaitTimer.Tick += new EventHandler(this.processWaitTimer_Tick);
      this.patternscanTimer.Interval = 10;
      this.patternscanTimer.Tick += new EventHandler(this.patternscanTimer_Tick);
      this.mainloopTimer.Interval = 200;
      this.mainloopTimer.Tick += new EventHandler(this.mainloopTimer_Tick);
      this.processStartTimer.Interval = 30000;
      this.processStartTimer.Tick += new EventHandler(this.processStartTimer_Tick);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(686, 177);
      this.Controls.Add((Control) this.flowLayoutPanel1);
      this.Controls.Add((Control) this.statusStrip1);
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (Form1);
      this.Text = "Stand for FH5";
      this.FormClosing += new FormClosingEventHandler(this.Form1_FormClosing);
      this.Load += new EventHandler(this.Form1_Load);
      this.Resize += new EventHandler(this.Form1_Resize);
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.lockcrVal.EndInit();
      this.flowLayoutPanel1.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.getSpinSuperVal.EndInit();
      this.getSpinRegularVal.EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
