﻿// Decompiled with JetBrains decompiler
// Type: Stand.Windows
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B37E4492-CA6E-4E66-880F-1A3CC762E837
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.3\Stand for FH5.exe

using System;
using System.Runtime.InteropServices;

namespace Stand
{
  internal class Windows
  {
    [DllImport("User32.dll", CharSet = CharSet.Ansi, ThrowOnUnmappableChar = true, BestFitMapping = false)]
    public static extern IntPtr LoadCursorFromFile(string str);

    [DllImport("user32.dll")]
    public static extern bool SetSystemCursor(IntPtr hcur, OCR_SYSTEM_CURSORS id);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool DestroyIcon(IntPtr hIcon);
  }
}
