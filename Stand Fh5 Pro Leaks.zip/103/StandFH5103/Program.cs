﻿// Decompiled with JetBrains decompiler
// Type: Stand.Program
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B37E4492-CA6E-4E66-880F-1A3CC762E837
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.3\Stand for FH5.exe

using System;
using System.Windows.Forms;

namespace Stand
{
  internal static class Program
  {
    [STAThread]
    private static void Main()
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run((Form) new Form1());
    }
  }
}
