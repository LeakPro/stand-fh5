﻿// Decompiled with JetBrains decompiler
// Type: Stand.OCR_SYSTEM_CURSORS
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B37E4492-CA6E-4E66-880F-1A3CC762E837
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.3\Stand for FH5.exe

namespace Stand
{
  public enum OCR_SYSTEM_CURSORS : uint
  {
    OCR_NORMAL = 32512, // 0x00007F00
    OCR_IBEAM = 32513, // 0x00007F01
    OCR_WAIT = 32514, // 0x00007F02
    OCR_CROSS = 32515, // 0x00007F03
    OCR_UP = 32516, // 0x00007F04
    OCR_SIZENWSE = 32642, // 0x00007F82
    OCR_SIZENESW = 32643, // 0x00007F83
    OCR_SIZEWE = 32644, // 0x00007F84
    OCR_SIZENS = 32645, // 0x00007F85
    OCR_SIZEALL = 32646, // 0x00007F86
    OCR_NO = 32648, // 0x00007F88
    OCR_HAND = 32649, // 0x00007F89
    OCR_APPSTARTING = 32650, // 0x00007F8A
    OCR_HELP = 32651, // 0x00007F8B
  }
}
