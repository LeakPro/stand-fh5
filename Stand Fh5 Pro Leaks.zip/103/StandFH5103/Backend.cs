﻿// Decompiled with JetBrains decompiler
// Type: Stand.Backend
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B37E4492-CA6E-4E66-880F-1A3CC762E837
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.3\Stand for FH5.exe

using System.Runtime.InteropServices;
using System.Text;

namespace Stand
{
  internal class Backend
  {
    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    public static extern bool checkProcess();

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void mainloop(StringBuilder a1, long a2);

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void die();

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void patternscanInit();

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern int patternscanStatus();

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void getSpinRegular(int amount);

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void getSpinSuper(int amount);

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void lockcrSet(int amount);

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void lockcrUnset();

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void autoshowAllfree();

    [DllImport("Backend.dll", CallingConvention = CallingConvention.Cdecl)]
    public static extern void autoshowAvailableSet(int mode);
  }
}
