﻿// Decompiled with JetBrains decompiler
// Type: Stand.State
// Assembly: Stand for FH5, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B37E4492-CA6E-4E66-880F-1A3CC762E837
// Assembly location: C:\Users\xboxh\Downloads\Stand for FH5 1.0.3\Stand for FH5.exe

using System;
using System.Windows.Forms;

namespace Stand
{
  internal class State
  {
    public static bool game_focused = false;
    public static IntPtr cursor_og = IntPtr.Zero;
    public static Cursor cursor_replacement = (Cursor) null;
  }
}
